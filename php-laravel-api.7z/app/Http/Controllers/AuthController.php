<?php 
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Exception;
use App\Helpers\JWTHelper;
use Illuminate\Http\Request;
/**
 * Index Page Controller
 * @category  Controller
 */
class AuthController extends Controller{
	/**
     * Login Action
     * @return \Illuminate\View\View
     */
	function login($formdata = null){
		//implement login
	}
	/**
     * Register Action
     * @return \Illuminate\View\View
     */
	function register($formdata = null){
		//implement register
	}
}
