<?php
namespace App\Http\Requests;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
class Users_TbAddRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
		
        return [
            
				"matric_no" => "required|string",
				"firstname" => "required|string",
				"lastname" => "required|string",
				"email" => "required|email",
				"phone" => "nullable|string",
				"department" => "required",
				"level" => "nullable|string",
				"password" => "required|same:confirm_password",
				"status" => "required|numeric",
				"email_link" => "nullable|email",
				"email_comfirm" => "required|numeric",
				"email_token" => "nullable|email",
				"gender" => "nullable",
				"deleted" => "required|numeric",
        ];
    }

	public function messages()
    {
        return [
            //using laravel default validation messages
        ];
    }

	/**
     * If validator fails return the exception in json form
     * @param Validator $validator
     * @return array
     */
    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json($validator->errors(), 422));
    }
}
