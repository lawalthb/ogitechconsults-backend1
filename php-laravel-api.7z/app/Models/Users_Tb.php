<?php 
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class Users_Tb extends Model 
{
	

	/**
     * The table associated with the model.
     *
     * @var string
     */
	protected $table = 'users_tb';
	

	/**
     * The table primary key field
     *
     * @var string
     */
	protected $primaryKey = 'user_id';
	

	/**
     * Table fillable fields
     *
     * @var array
     */
	protected $fillable = ["matric_no","firstname","lastname","email","phone","department","level","password","status","email_link","email_comfirm","email_token","gender","deleted"];
	

	/**
     * Set search query for the model
	 * @param \Illuminate\Database\Eloquent\Builder $query
	 * @param string $text
     */
	public static function search($query, $text){
		//search table record 
		$search_condition = '(
				matric_no LIKE ?  OR 
				firstname LIKE ?  OR 
				lastname LIKE ?  OR 
				email LIKE ?  OR 
				phone LIKE ?  OR 
				level LIKE ?  OR 
				password LIKE ?  OR 
				email_link LIKE ?  OR 
				email_token LIKE ?  OR 
				gender LIKE ? 
		)';
		$search_params = [
			"%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%"
		];
		//setting search conditions
		$query->whereRaw($search_condition, $search_params);
	}
	

	/**
     * return list page fields of the model.
     * 
     * @return array
     */
	public static function listFields(){
		return [ 
			"user_id", 
			"matric_no", 
			"firstname", 
			"lastname", 
			"email", 
			"phone", 
			"department", 
			"level", 
			"status", 
			"email_link", 
			"email_comfirm", 
			"email_token", 
			"reg_date", 
			"gender", 
			"deleted" 
		];
	}
	

	/**
     * return exportList page fields of the model.
     * 
     * @return array
     */
	public static function exportListFields(){
		return [ 
			"user_id", 
			"matric_no", 
			"firstname", 
			"lastname", 
			"email", 
			"phone", 
			"department", 
			"level", 
			"status", 
			"email_link", 
			"email_comfirm", 
			"email_token", 
			"reg_date", 
			"gender", 
			"deleted" 
		];
	}
	

	/**
     * return view page fields of the model.
     * 
     * @return array
     */
	public static function viewFields(){
		return [ 
			"user_id", 
			"matric_no", 
			"firstname", 
			"lastname", 
			"email", 
			"phone", 
			"department", 
			"level", 
			"status", 
			"email_link", 
			"email_comfirm", 
			"email_token", 
			"reg_date", 
			"gender", 
			"deleted" 
		];
	}
	

	/**
     * return exportView page fields of the model.
     * 
     * @return array
     */
	public static function exportViewFields(){
		return [ 
			"user_id", 
			"matric_no", 
			"firstname", 
			"lastname", 
			"email", 
			"phone", 
			"department", 
			"level", 
			"status", 
			"email_link", 
			"email_comfirm", 
			"email_token", 
			"reg_date", 
			"gender", 
			"deleted" 
		];
	}
	

	/**
     * return edit page fields of the model.
     * 
     * @return array
     */
	public static function editFields(){
		return [ 
			"user_id", 
			"matric_no", 
			"firstname", 
			"lastname", 
			"email", 
			"phone", 
			"department", 
			"level", 
			"status", 
			"email_link", 
			"email_comfirm", 
			"email_token", 
			"gender", 
			"deleted" 
		];
	}
	

	/**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
	public $timestamps = false;
}
